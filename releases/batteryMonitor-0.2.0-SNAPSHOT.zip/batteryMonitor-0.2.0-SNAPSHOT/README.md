# Technical documentation

BatteryMonitor is a simple battery monitor
to protect your robots when has battery has a low level.

The release batteryMonitor will includes:

+ A fatJar with the solution to measure the battery
+ Linux service (batteryMonitor-service.sh) to be installed on `/etc/init.d`
+ Scripts to Start & Stop the service

The solution will be managed by the Installer:
https://github.com/ev3dev-lang-java/installer

