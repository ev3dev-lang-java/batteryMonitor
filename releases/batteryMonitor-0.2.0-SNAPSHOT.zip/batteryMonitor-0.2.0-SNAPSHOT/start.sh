#!/bin/bash

java -server -Dlogback.configurationFile=/home/robot/batteryMonitor/logback.xml -jar /home/robot/batteryMonitor/batteryMonitor-all-0.2.0-SNAPSHOT.jar &

